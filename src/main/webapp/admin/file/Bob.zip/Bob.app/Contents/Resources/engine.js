// window
var window = this;

// global
var global = this;

// module
function Module(props) {
    this.exports = props.exports || {};
    this.filename = props.filename;
    this.dirname = props.dirname;
}

Module.prototype.require = function (path) {
    return __loadModule__(path, this).exports;
};

function __createModule__(props) {
    return new Module(props || {});
}

// require
function __makeRequireFunction__(mod) {
    var require = function (path) {
        return mod.require(path);
    }
    return require;
}

var __moduleCache__ = Object.create(null);

function __loadModule__(path, parent) {
    $log.info(`load module: path=${path}; parent=${JSON.stringify(parent)}`);

    var resolved = __oc_require_resolve_path(path, parent.dirname);
    if (!resolved) {
        return null;
    }
    var filename = resolved.filename;
    var dirname = resolved.dirname;

    var cachedModule = __moduleCache__[filename];

    if (cachedModule) {
        return cachedModule;
    }

    var source = __oc_require_read_file(resolved);
    if (!source) {
        return null;
    }

    var module = __createModule__({
        exports: {},
        filename,
        dirname,
    });

    // 加载代码之前，先存入缓存，防止模块之间循环引用
    __moduleCache__[filename] = module;

    try {
        var require = __makeRequireFunction__(module);
        
        // 1. 直接在js中加载
        // var execute = new Function("exports, require, module, __filename, __dirname", source);
        // execute(module.exports, require, module, filename, dirname);
        
        // 2. 在OC代码中加载模块，方便debug
        __oc_require_evaluate(source, module.exports, require, module, filename, dirname);
    } catch (error) {
        error.message += ` (load mudule: path=${path}; parent=${JSON.stringify(parent)})`;
        __oc_catch(error);
    }

    return module;
}

// main module
var module = __createModule__({
    exports: {},
    filename: "/main.js",
    dirname: "/"
});
var require = __makeRequireFunction__(module);
var exports = module.exports;
var __filename = module.filename;
var __dirname = module.dirname;
__moduleCache__[module.filename] = module;

// release
function __release__() {
    exports = null;
    require = null;
    module = null;
    __dirname = null;
    __filename = null;
    __moduleCache__ = null;
}

// try call
function __tryCall__(func, arguments, catchCallback) {
    if (typeof func !== 'function') {
        if (typeof catchCallback === 'function') {
            var error = new Error(`${func} is not a function.`);
            __oc_catch(error);
            catchCallback(false, error);
        }
        return;
    }
    
    try {
        return func.apply(null, arguments);
    } catch (error) {
        if (typeof catchCallback === 'function') {
            __oc_catch(error);
            catchCallback(true, error);
        }
    }
}
